#!/bin/sh

set -x

javac -cp .:afs_servidor.jar ServidorAFS.java
