#include <stdio.h>
#include "comun.h"
#include "diccionario.h"
#include "cola.h"
#include <stdlib.h>
#include <unistd.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <stdint.h>
#include <sys/types.h>
#include <netdb.h>
#include <string.h>
#include <sys/uio.h>

#define TAM 2048

struct diccionario *d;

void visitar_dic(char *clave,void *valor){
  printf("%s\n",clave);
}

void visitar_cola(void *valor){
  printf("%s\n",valor);
}



void destruir_entrada(char *c, void *v){
  free(c);
  if(cola_destroy(v,NULL)<0){
   perror("Entry not destroyed");
  }
}


int main(int argc, char *argv[]) {
  int s, s_conec;
	unsigned int tam_dir;
	struct sockaddr_in dir, dir_cliente;
	int opcion=1;
	int bytesw;
	int bytesr;

	
	d= dic_create();
	
	
	if (argc!=2) {
		fprintf(stderr, "Uso: %s puerto\n", argv[0]);
		return 1;
	}
	if ((s=socket(PF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0) {
		perror("Socket not created");
		return 1;
	}
	
        if (setsockopt(s, SOL_SOCKET, SO_REUSEADDR, &opcion, sizeof(opcion))<0){
                perror("error en setsockopt");
                return 1;
        }
	dir.sin_addr.s_addr=INADDR_ANY;
	dir.sin_port=htons(atoi(argv[1]));
	dir.sin_family=PF_INET;
	if (bind(s, (struct sockaddr *)&dir, sizeof(dir)) < 0) {
		perror("error en bind");
		close(s);
		return 1;
	}
	if (listen(s, 5) < 0) {
		perror("error en listen");
		close(s);
		return 1;
	}
	void *msg;
        uint32_t *msgsize;
	while(1){
	        tam_dir=sizeof(dir_cliente);
		if ((s_conec=accept(s, (struct sockaddr *)&dir_cliente, &tam_dir))<0){
			perror("error en accept");
			close(s);
			return 1;
		}	       
        
		
		int elige;
		
		bytesr = read(s_conec,&elige,sizeof(int));
		if(bytesr<0){
		  perror("Failed reading s_conec");
		  close(s);
		  close(s_conec);
		  return 1;
		}
		
		int sret;
		int sizecola;
	       
		switch(elige){
		  
		case 1:
		    if(read(s_conec,&sizecola,sizeof(int))<0){
		    perror("Error reading cola size");
		    close(s);
		    close(s_conec);
		    return 1;
		    
		  }
		 
		  char *mcola;
		  mcola = (char *)malloc(sizecola + 1);
		  if(recv(s_conec,mcola,sizecola,MSG_WAITALL)<0){
		    perror("Error reading cola");
		    close(s);
		    close(s_conec);
		    return 1;
		  }
		  
		  mcola[sizecola]=0;
		  struct cola *cola;
		  cola = cola_create();
		  if(cola==NULL){
		    perror("Error creating cola");
		    sret =  -1;
		    break;
		  }
		  if(dic_put(d,mcola,cola)<0){
		    perror("Failed to add to diccionario");
		    sret =  -1;
		    break;
		  }
		  dic_visit(d,visitar_dic);
		  sret = 0;
		  break;
		    
		case 2:
		  
		  if(read(s_conec,&sizecola,sizeof(int))<0){
		   perror("Error reading cola size");
		   close(s);
		   close(s_conec);
		   return 1;
		  }
		  
		  char *mcola3;
		  mcola3 = (char *)malloc(sizecola+1);
		  if(recv(s_conec,mcola3,sizecola,MSG_WAITALL)<0){
		    perror("Error reading cola");
		    close(s);
		    close(s_conec);
		    return 1;
		  }
		  mcola3[sizecola]=0;
 
		  struct cola *cola2;
		  int error;
		  cola2 = dic_get(d,mcola3,&error);
		  if(error<0){
		    perror("Cola does not exist");
		    sret = -1;
		    break;
		  }
  
		  msgsize = cola_pop_front(cola2, &error);
		  if(error<0){
		    perror("Failed to extract message size");
		    sret =  2;
		    break;
		  }
		  msg = cola_pop_front(cola2,&error);
		  if(error<0){
		    perror("Error extracting message");
		    sret =  2;
		    break;
		  }
	      
	      
		  sret = 0;
		  break;
		  
		case 3 :
		   if(read(s_conec,&sizecola,sizeof(int))<0){
		    perror("Error reading cola size");
		    close(s);
		    close(s_conec);
		    return 1;
		  }
		  char *mcola2;
		  mcola2 = (char *)malloc(sizecola+1);
		  if(recv(s_conec,mcola2,sizecola,MSG_WAITALL)<0){
		    perror("Error reading cola");
		    close(s);
		    close(s_conec);
		    return 1;
		  }
		  mcola2[sizecola]=0;
		  msgsize = (uint32_t *)malloc(sizeof (uint32_t));
		  if(read(s_conec,msgsize,sizeof(uint32_t))<0){
		    perror("Error reading message size");
		    close(s);
		    close(s_conec);
		    return 1;
		  }
	      
		  
		  msg = malloc(*msgsize);
		  if(recv(s_conec,msg,*msgsize,MSG_WAITALL)<0){
		    perror("Error reading message");
		    close(s);
		    close(s_conec);
		    return 1;
		  }
  
		  struct cola *cola3;
		  int error1;
		  cola3 = dic_get(d,mcola2,&error1);
		  if(error1<0){
		    perror("Cola does not exist");
		    sret = -1;
		    break;
		  }
	       
		  if(cola_push_back(cola3,msgsize)<0){
		    perror("Error introducing size");
		    sret = -1;
		    break;
		  }
	     
		  if(cola_push_back(cola3,msg)<0){
		    perror("Error introducing message");
		    sret = -1;
		    break;
		  }
		  sret =  0;

		 break;
		 
		case 4 :
		   if(read(s_conec,&sizecola,sizeof(int))<0){
		    perror("Error reading cola size");
		    close(s);
		    close(s_conec);
		    return 1;
		  }
		  char *mcola1;
		  mcola1 = (char *)malloc(sizecola+1);
		  if(recv(s_conec,mcola1,sizecola,MSG_WAITALL)<0){
		    perror("Error reading cola");
		    close(s);
		    close(s_conec);
		    return 1;
		  }
		  mcola1[sizecola]=0;

		  if(dic_remove_entry(d,mcola1,destruir_entrada)<0){
		    perror("Failed to delete entry");
		    sret = -1;
		    break;
		  }
		  dic_visit(d,visitar_dic);
		  sret = 0;
		  break;
		  
		 default :
		  perror("Invalid operation");
		  close(s);
		  close(s_conec);
		  return 1;
		}
		
	       
		
		if(elige ==2 && sret==0){
		  struct iovec iov1[3];
		  iov1[0].iov_base = &sret;
		  iov1[0].iov_len = sizeof(sret);
		  iov1[1].iov_base = msgsize;
		  iov1[1].iov_len = sizeof(*msgsize);
		  iov1[2].iov_base = msg;
		  iov1[2].iov_len = *msgsize;
		  bytesw = writev(s_conec,iov1,3);
		  if(bytesw<0){
		    perror("Error writing the message on s_conec");
		    close(s);
		    close(s_conec);
		    return 1;
		  }
		}  
		  else{  
		    struct iovec iov[1];
		    iov[0].iov_base = &sret;
		    iov[0].iov_len = sizeof(sret);
		    bytesw = writev(s_conec,iov,1);
		    if(bytesw<0){
		      perror("Error writing on s_conec");
		      close(s);
		      close(s_conec);
		      return 1;
		  }
		 

		}
		close(s_conec);
}
	close(s);
	
	dic_destroy(d,NULL);
	return 0;
}





