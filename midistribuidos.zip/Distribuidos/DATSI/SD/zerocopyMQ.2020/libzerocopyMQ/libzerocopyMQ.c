#include <stdint.h>
#include "zerocopyMQ.h"
#include "comun.h"
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <sys/uio.h>

#define TAM 1024

int createMQ(const char *cola) {
  
        int s;
	struct sockaddr_in dir;
	struct hostent *host_info;
	int msgin;
	msgin = 1;
	if ((s=socket(PF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0) {
		perror("error creando socket");
		return -1;
	}



	char *varbroker;
	varbroker = getenv("BROKER_PORT");
	char *varhost;
	varhost = getenv("BROKER_HOST");
	
	host_info=gethostbyname(varhost);
	dir.sin_addr=*(struct in_addr *)host_info->h_addr;
	dir.sin_port=htons(atoi(varbroker));
	dir.sin_family=PF_INET;


	if (connect(s, (struct sockaddr *)&dir, sizeof(dir)) < 0) {
		perror("error en connect");
		close(s);
		return -1;
	}



	unsigned int sizecola = strlen(cola);
	struct iovec iov[3];
	iov[0].iov_base =&msgin;
	iov[0].iov_len = sizeof(msgin);
	iov[1].iov_base = &sizecola;
        iov[1].iov_len = sizeof(sizecola);
	iov[2].iov_base = cola;
	iov[2].iov_len = sizecola;
	if(writev(s,iov,3)<0){
	  perror("Writing error");
	  close(s);
	  return -1;
	}
	
	int leido;
	int ret;
	leido = read(s,&ret,sizeof(int));
	if(leido<0){
	  perror("Reading error");
	  close(s);
	  return -1;
	}
	close(s);
	return ret;
}

int destroyMQ(const char *cola){

        int s;
	struct sockaddr_in dir;
	struct hostent *host_info;
	int msgin;
	msgin = 4;
        if ((s=socket(PF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0) {
	    perror("error creando socket");
	    return -1;
	}

	char *varbroker;
	varbroker = getenv("BROKER_PORT");
	char *varhost;
	varhost = getenv("BROKER_HOST");
	
	host_info=gethostbyname(varhost);
	dir.sin_addr=*(struct in_addr *)host_info->h_addr;
	dir.sin_port=htons(atoi(varbroker));
	dir.sin_family=PF_INET;
	if (connect(s, (struct sockaddr *)&dir, sizeof(dir)) < 0) {
		perror("error en connect");
		close(s);
		return -1;
	}
      
	unsigned int sizecola = strlen(cola);
	struct iovec iov[3];
	iov[0].iov_base = &msgin;
	iov[0].iov_len = sizeof(msgin);
	iov[1].iov_base = &sizecola;
	iov[1].iov_len = sizeof(sizecola);
	iov[2].iov_base = cola;
	iov[2].iov_len = sizecola;
	if(writev(s,iov,3)<0){
	  perror("Writing error");
	  close(s);
	  return -1;
	}
	int leido;
	int ret;
	leido = read(s,&ret,sizeof(int));
	if(leido<0){
	  perror("Reading error");
	  close(s);
	  return -1;
	}
	close(s);
	return ret;
}


int put(const char *cola, const void *mensaje, uint32_t tam) {
        printf("Ha entrado en put \n");
        int s, leido;
	struct sockaddr_in dir;
	struct hostent *host_info;
	int msgin;
	msgin = 3;
	if ((s=socket(PF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0) {
		perror("error creando socket");
		return -1;
	}

	char *varbroker;
	varbroker = getenv("BROKER_PORT");
	char *varhost;
	varhost = getenv("BROKER_HOST");
	
	host_info=gethostbyname(varhost);
	dir.sin_addr=*(struct in_addr *)host_info->h_addr;
	dir.sin_port=htons(atoi(varbroker));
	dir.sin_family=PF_INET;
	if (connect(s, (struct sockaddr *)&dir, sizeof(dir)) < 0) {
		perror("error en connect");
		close(s);
		return -1;
	}


	unsigned int sizecola = strlen(cola);
        struct iovec iov[5];

	iov[0].iov_base = &msgin;
	iov[0].iov_len = sizeof(msgin);
	iov[1].iov_base = &sizecola;
	iov[1].iov_len = sizeof(sizecola);
	iov[2].iov_base = cola;
	iov[2].iov_len = sizecola;
	iov[3].iov_base = &tam;
	iov[3].iov_len = sizeof(uint32_t);
	iov[4].iov_base = mensaje;
	iov[4].iov_len = tam;
	if(writev(s,iov,5)<0){
	  perror("Writing error");
	  close(s);
	  return -1;
	}	
	int ret;
	leido = read(s,&ret,sizeof(int));
	if(leido<0){
	  perror("Readin error");
	  close(s);
	  return -1;
	}

	close(s);
	return ret;
    
}

int get(const char *cola, void **mensaje, uint32_t *tam, bool blocking) {
        printf("Ha entrado en get dentro de libzerocopyMQ \n");
        int s, leido;
	struct sockaddr_in dir;
	struct hostent *host_info;
        int msgin;
	msgin = 2;
	if ((s=socket(PF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0) {
		perror("error creando socket");
		return -1;
	}

	char *varbroker;
	varbroker = getenv("BROKER_PORT");
	char *varhost;
	varhost = getenv("BROKER_HOST");
	
	host_info=gethostbyname(varhost);
	dir.sin_addr=*(struct in_addr *)host_info->h_addr;
	dir.sin_port=htons(atoi(varbroker));
	dir.sin_family=PF_INET;
	if (connect(s, (struct sockaddr *)&dir, sizeof(dir)) < 0) {
		perror("error en connect");
		close(s);
		return -1;
	}


	unsigned int sizecola = strlen(cola);
        struct iovec iov[3];

	iov[0].iov_base = &msgin;
	iov[0].iov_len = sizeof(msgin);
	iov[1].iov_base = &sizecola;
	iov[1].iov_len = sizeof(sizecola);
	iov[2].iov_base = cola;
	iov[2].iov_len = sizecola;
	if(writev(s,iov,3)<0){
	  perror("Writing error");
	  close(s);
	  return -1;
	}	
	int ret;
	leido = read(s,&ret,sizeof(int));
	if(leido<0){
	  perror("Reading error");
	  close(s);
	  return -1;
	}
	if(ret==2){
	  tam = 0;
	  close(s);
	  return 0;
	}
	if(ret==0){
	  
	  if(read(s,tam,sizeof(uint32_t))<0){
	    perror("Error reading message sizee");
	    close(s);
	    return -1;
	  }
	  printf("%u \n",*tam);
	  *mensaje = malloc(*tam);
	  if(recv(s,*mensaje,*tam,MSG_WAITALL)<0){
	    perror("Error reading cola size");
	    close(s);
	    return -1;
	  }
	  close(s);
	  return 0;
	}
	else{
	  close(s);
	  return -1;
	}
}
